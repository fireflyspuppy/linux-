# MCP Demo Server

A minimal MCP (Model Context Protocol) server demonstrating tool authentication.

## Tools

- **get_token** — Get an auth token (no auth required)
- **get_system_info** — Returns system info (OS, CPU count, Python version, server time). Requires token.

## Install

```bash
pip install -r requirements.txt
```

## Run

Configure in `.mcp.json`:

```json
{
  "mcpServers": {
    "mcp-demo": {
      "command": "python",
      "args": ["-3.13", "path/to/mcp_server.py"]
    }
  }
}
```

## Test

```bash
python test_mcp.py
```
