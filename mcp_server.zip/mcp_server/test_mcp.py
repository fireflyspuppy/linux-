import asyncio
import json
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp import ClientSession

async def test():
    server = StdioServerParameters(
        command=r"C:\Windows\py.exe",
        args=[r"-3.13", r"C:\Users\zyhan\Desktop\mcp_server\mcp_server.py"],
    )
    async with stdio_client(server) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            print("=== 工具列表 ===")
            for t in tools.tools:
                print(f"  - {t.name}: {t.description}")

            print()
            print("=== 调用 get_token ===")
            result = await session.call_tool("get_token", {})
            text = result.content[0].text
            print(f"  结果: {text}")
            token_data = json.loads(text)
            token = token_data["token"]
            print(f"  Token: {token}")

            print()
            print("=== 调用 get_system_info (无 token) ===")
            result = await session.call_tool("get_system_info", {})
            print(f"  isError: {result.isError}")
            print(f"  结果: {result.content[0].text}")

            print()
            print("=== 调用 get_system_info (错误 token) ===")
            result = await session.call_tool("get_system_info", {"token": "wrong-token"})
            print(f"  isError: {result.isError}")
            print(f"  结果: {result.content[0].text}")

            print()
            print("=== 调用 get_system_info (正确 token) ===")
            result = await session.call_tool("get_system_info", {"token": token})
            print(f"  isError: {result.isError}")
            print(f"  结果: {result.content[0].text}")

asyncio.run(test())
