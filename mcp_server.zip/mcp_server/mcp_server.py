import json
import uuid
import platform
import os
import sys
import datetime
from contextlib import asynccontextmanager

from mcp.server import Server
from mcp.types import Tool, TextContent
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from starlette.applications import Starlette
from starlette.routing import Route
import uvicorn

# 服务启动时生成 token，仅存内存
CURRENT_TOKEN = str(uuid.uuid4())


def require_token(token: str | None) -> None:
    if not token:
        raise ValueError("缺少鉴权参数 token，请先调用 get_token 获取。")
    if token != CURRENT_TOKEN:
        raise ValueError("token 无效，请重新调用 get_token 获取最新 token。")


# -------- 工具处理函数 --------

def handle_get_token(_args: dict) -> dict:
    return {"token": CURRENT_TOKEN}


def handle_get_system_info(args: dict) -> dict:
    token = args.get("token")
    require_token(token)

    return {
        "os": f"{platform.system()} {platform.release()}",
        "cpu_count": os.cpu_count(),
        "python_version": sys.version.split()[0],
        "server_time": datetime.datetime.now().isoformat(),
    }


# -------- MCP 服务 --------

server = Server("mcp-demo")

GET_TOKEN_SCHEMA = {
    "type": "object",
    "properties": {},
}

GET_SYSTEM_INFO_SCHEMA = {
    "type": "object",
    "properties": {
        "token": {
            "type": "string",
            "description": "鉴权 token，通过 get_token 工具获取。",
        }
    },
    "required": ["token"],
}


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="get_token",
            description="获取鉴权所需的 token。无需鉴权即可调用。",
            inputSchema=GET_TOKEN_SCHEMA,
        ),
        Tool(
            name="get_system_info",
            description="返回系统信息（操作系统、CPU 核数、Python 版本、服务器时间）。需要鉴权 token，请先调用 get_token 获取。",
            inputSchema=GET_SYSTEM_INFO_SCHEMA,
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "get_token":
        result = handle_get_token(arguments)
        return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]
    elif name == "get_system_info":
        result = handle_get_system_info(arguments)
        return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]
    else:
        raise ValueError(f"未知工具: {name}")


def main():
    host = os.environ.get("MCP_HOST", "0.0.0.0")
    port = int(os.environ.get("MCP_PORT", "8000"))

    session_manager = StreamableHTTPSessionManager(app=server, stateless=True)

    @asynccontextmanager
    async def lifespan(app: Starlette):
        async with session_manager.run():
            yield

    class MCPASGIApp:
        async def __call__(self, scope, receive, send):
            await session_manager.handle_request(scope, receive, send)

    app = Starlette(
        lifespan=lifespan,
        routes=[Route("/mcp", MCPASGIApp(), methods=["GET", "POST", "DELETE"])],
    )

    print(f"[MCP Demo Server] 启动中... http://{host}:{port}/mcp  Token: {CURRENT_TOKEN}", file=sys.stderr, flush=True)
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
